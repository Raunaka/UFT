*********************************
&&MINI PROJECT&&
*********************************
Find the number of hotels available in Mumbai with price between  Rs. 2000 to Rs. 3000 for 1 day in next week.
Search for hotels online  to stay in Mumbai for below details
1. stay will for 2 days in next week.
2. Hotel price should be between Rs. 2000 to Rs. 3000 for 1 day.
*********************************
&&WEBSITE&&
*********************************
booking.com for hotel booking
url
https://www.booking.com
